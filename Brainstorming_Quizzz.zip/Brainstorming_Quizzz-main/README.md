# Brainstorming_Quizzz

Wonder How we can you make an amazing Quiz Application using HTML CSS JS? If No, this will be the perfect repo for you.

###### **Here is the link of [Live Demo](https://javascript-quiz99.netlify.app/)**


## Technology Stack Used

![HTML](https://img.shields.io/badge/frontend-html-orange.svg?logo=html5&style=flat-square) 
![CSS](https://img.shields.io/badge/frontend-css-yellowgreen.svg?logo=css3&style=flat-square)
![JavaScript](https://img.shields.io/badge/frontend-javascript-blue.svg?logo=javascript&style=flat-square) 


- Front End - **HTML**, **CSS** , **JavaScript**

### Still need help?

```

  if (needHelp === true) {
     var emailId = "shalurajput9951@gmail.com";
     // email is the best way to reach out to me.
     sendEmail(emailId);
  }

```

***Glad to see you here! Show some love by [starring](https://github.com/smilegupta/brainstorming_Quizzz/) this repo.***


